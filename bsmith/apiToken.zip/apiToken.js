const rp = require('request-promise');
const shuffle = require('shuffle-array');
const _ = require('lodash');
const Promise = require('bluebird');

const endpoint = 'https://qa4-rc.aprimo.com/api/oauth/create-native-token';
const options = {
    method: 'POST',
    uri: endpoint,
    headers: {
        'content-type': 'application/json',
        'client-id': 'L4AIEHMR-FJSP',
        'Authorization': 'Basic bG9hZHVzZXI0OTpjZjRhYTExMjM2OTY0YThhYWFkYzE2NWEzYTc1OGQxNQ=='
    },
    json: true
};

const rps = 100;
var cnt = 0;
var urls = [];
for(var i = 0; i < rps; i++) {
    urls.push(endpoint);
}

Promise.map(urls, function (url) {
    rp(options).then(function (response) {
        cnt++;
        console.log(cnt + ': OK');
        console.log(response);
    }).catch(function (error) {
        cnt++;
        console.log(cnt + ': ' + error.statusCode);
    });
});